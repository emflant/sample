## rappdirs 0.3.1

Minor R CMD check and test fixes.

## rappdirs 0.3.0

* first CRAN release
* `xxx_dir()` functions only use version when appname is not null
* docs: basic package docs (?rappdirs)
* docs: clarify primary purpose of os argument in `xxx_dir()` i.e. testing
* fix typo in function name in README.md (app_dirs -> app_dir)
* dev: add travis continuous integration
* dev: add rstudio project
* dev: update to roxygen2 v4.0.1
